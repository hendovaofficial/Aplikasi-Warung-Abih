import 'package:flutter/material.dart';
import 'add_product_screen.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Admin Warung Abih')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.inventory_2_outlined)),
            title: const Text('Kelola Produk', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('Tambah dan kelola barang jualan'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => const ProductManagementScreen(),
            )),
          ),
        ),
        Card(child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.receipt_long_outlined)),
          title: const Text('Pesanan'),
          subtitle: const Text('Menu pesanan pelanggan'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {},
        )),
        Card(child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.settings_outlined)),
          title: const Text('Pengaturan'),
          subtitle: const Text('Pengaturan toko'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {},
        )),
      ],
    ),
  );
}

class ProductManagementScreen extends StatelessWidget {
  const ProductManagementScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Kelola Produk')),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.add_box_outlined),
              title: const Text('Tambah Produk', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Isi nama, harga, stok, kategori, dan lainnya'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => const AddProductScreen(),
              )),
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Produk yang sudah disimpan akan tampil di sini. Daftar produk akan kita sambungkan ke Firestore pada tahap berikutnya.'),
            ),
          ),
        ],
      ),
    ),
  );
}
