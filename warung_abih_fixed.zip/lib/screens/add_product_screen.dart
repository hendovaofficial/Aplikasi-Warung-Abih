import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _price = TextEditingController();
  final _stock = TextEditingController();
  final _description = TextEditingController();
  final _imageUrl = TextEditingController();

  String? _categoryId;
  bool _isActive = true;
  bool _saving = false;

  final _categories = const [
    {'id': 'beras', 'name': 'Beras'},
    {'id': 'minyak', 'name': 'Minyak Goreng'},
    {'id': 'gula', 'name': 'Gula'},
    {'id': 'telur', 'name': 'Telur'},
    {'id': 'mie', 'name': 'Mie Instan'},
    {'id': 'tepung', 'name': 'Tepung Terigu Biasa'},
  ];

  @override
  void dispose() {
    _name.dispose(); _price.dispose(); _stock.dispose();
    _description.dispose(); _imageUrl.dispose();
    super.dispose();
  }

  String? requiredField(String? v, String label) =>
      v == null || v.trim().isEmpty ? '$label wajib diisi' : null;

  Future<void> save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final price = int.parse(_price.text.replaceAll('.', '').replaceAll(',', ''));
      final stock = int.parse(_stock.text);
      final doc = FirebaseFirestore.instance.collection('products').doc();

      await doc.set({
        'name': _name.text.trim(),
        'price': price,
        'stock': stock,
        'categoryId': _categoryId,
        'description': _description.text.trim(),
        'isActive': _isActive,
        if (_imageUrl.text.trim().isNotEmpty) 'imageUrl': _imageUrl.text.trim(),
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Produk berhasil disimpan')),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menyimpan produk: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Tambah Produk')),
    body: Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Data Barang', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextFormField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Nama barang', hintText: 'Contoh: Beras 5 Kg', prefixIcon: Icon(Icons.shopping_bag_outlined)),
            validator: (v) => requiredField(v, 'Nama barang'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _price,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Harga', hintText: 'Contoh: 75000', prefixIcon: Icon(Icons.payments_outlined)),
            validator: (v) {
              if (requiredField(v, 'Harga') != null) return requiredField(v, 'Harga');
              return int.tryParse(v!.replaceAll('.', '').replaceAll(',', '')) == null ? 'Harga harus berupa angka' : null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _stock,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Stok', hintText: 'Contoh: 20', prefixIcon: Icon(Icons.inventory_2_outlined)),
            validator: (v) {
              if (requiredField(v, 'Stok') != null) return requiredField(v, 'Stok');
              return int.tryParse(v!) == null ? 'Stok harus berupa angka' : null;
            },
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _categoryId,
            decoration: const InputDecoration(labelText: 'Kategori', prefixIcon: Icon(Icons.category_outlined)),
            items: _categories.map((c) => DropdownMenuItem(value: c['id'], child: Text(c['name']!))).toList(),
            onChanged: (v) => setState(() => _categoryId = v),
            validator: (v) => v == null ? 'Kategori wajib dipilih' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _description,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'Deskripsi', hintText: 'Contoh: Beras kemasan 5 Kg', prefixIcon: Icon(Icons.description_outlined), alignLabelWithHint: true),
            validator: (v) => requiredField(v, 'Deskripsi'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _imageUrl,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(labelText: 'URL foto barang (opsional)', hintText: 'Boleh dikosongkan dulu', prefixIcon: Icon(Icons.image_outlined)),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Produk aktif'),
            subtitle: Text(_isActive ? 'Tampil ke pelanggan' : 'Disembunyikan dari pelanggan'),
            value: _isActive,
            onChanged: (v) => setState(() => _isActive = v),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _saving ? null : save,
              icon: _saving
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save_outlined),
              label: Text(_saving ? 'Menyimpan...' : 'Simpan Produk'),
            ),
          ),
        ],
      ),
    ),
  );
}
