class Product {
  final String id;
  final String name;
  final int price;
  final int stock;
  final String categoryId;
  final String description;
  final bool isActive;
  final String? imageUrl;

  const Product({
    required this.id,
    required this.name,
    required this.price,
    required this.stock,
    required this.categoryId,
    required this.description,
    required this.isActive,
    this.imageUrl,
  });
}
