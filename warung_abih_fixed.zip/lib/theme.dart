import 'package:flutter/material.dart';

ThemeData buildWarungTheme() => ThemeData(
  useMaterial3: true,
  colorSchemeSeed: Colors.green,
  scaffoldBackgroundColor: const Color(0xFFF7F8F7),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
  ),
);
