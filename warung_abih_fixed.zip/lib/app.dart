import 'package:flutter/material.dart';
import 'theme.dart';
import 'screens/admin_screen.dart';

class WarungAbihApp extends StatelessWidget {
  const WarungAbihApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Warung Abih',
      debugShowCheckedModeBanner: false,
      theme: buildWarungTheme(),
      home: const AdminScreen(),
    );
  }
}
