# Warung Abih Flutter App v2

Menu Admin > Kelola Produk > Tambah Produk sudah tersedia.

Form:
- Nama barang
- Harga
- Stok
- Kategori
- Deskripsi
- URL foto (opsional)
- Status Aktif/Nonaktif
- Simpan Produk

Data disimpan ke Firestore collection top-level `products`.
Project ini adalah source Flutter, bukan APK siap instal.

Sebelum build:
1. Jalankan `flutterfire configure` dan pilih project `warung-abih`.
2. `flutter pub get`
3. `flutter run` atau `flutter build apk`
