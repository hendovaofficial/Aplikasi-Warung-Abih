BUILD APK DARI HP

1. Buat repository GitHub baru, misalnya: warung-abih-app
2. Upload seluruh isi project ini ke repository.
3. Buka tab Actions.
4. Pilih workflow "Build Warung Abih APK".
5. Tekan Run workflow.
6. Setelah selesai, buka hasil workflow dan bagian Artifacts.
7. Download artifact "warung-abih-apk" lalu ambil app-release.apk.

Catatan:
- Build ini adalah versi awal.
- Firebase configuration Android belum dibundel karena bersifat khusus project.
- Aplikasi dapat dibuka sebagai UI, tetapi penyimpanan Firestore memerlukan konfigurasi Firebase Android.
