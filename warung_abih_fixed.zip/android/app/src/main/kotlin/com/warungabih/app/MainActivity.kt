package com.warungabih.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
