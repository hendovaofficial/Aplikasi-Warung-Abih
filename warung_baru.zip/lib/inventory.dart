import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'data.dart';

Future<void> exportCsv(BuildContext context, String filename, String csv) async {
  try {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$filename');
    await file.writeAsString(csv);
    await Share.shareXFiles([XFile(file.path)], text: 'Data dari ${store.shop}');
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal ekspor: $e')));
    }
  }
}

String csvEscape(String s) => '"${s.replaceAll('"', '""')}"';

class GudangPage extends StatelessWidget {
  const GudangPage({super.key});

  Future<void> _export(BuildContext context) async {
    final b = StringBuffer('Nama,SKU,Kategori,Stok,Satuan,Harga Beli,Harga Jual\n');
    for (final p in store.products) {
      b.writeln('${csvEscape(p.name)},${csvEscape(p.sku)},${csvEscape(p.category)},${p.stock},${csvEscape(p.unit)},${p.costPrice},${p.price}');
    }
    await exportCsv(context, 'stok_${store.shop}.csv', b.toString());
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final habis = store.products.where((p) => p.stock == 0).length;
        final menipis = store.products.where((p) => p.stock > 0 && p.stock <= 5).length;
        return Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(
                child: _pill('Stok Habis', '$habis', Colors.red),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _pill('Stok Menipis (≤5)', '$menipis', Colors.orange),
              ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.history),
                  label: const Text('Riwayat Stok'),
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Riwayat Stok')), body: const StockHistoryPage()))),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.icon(
                  icon: const Icon(Icons.ios_share),
                  label: const Text('Ekspor CSV'),
                  onPressed: () => _export(context),
                ),
              ),
            ]),
          ),
          const Divider(height: 20),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              itemCount: store.products.length,
              itemBuilder: (_, i) {
                final p = store.products[i];
                return ListTile(
                  title: Text(p.name),
                  subtitle: Text(p.category),
                  trailing: Text(
                    '${p.stock} ${p.unit}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: p.stock == 0 ? Colors.red : (p.stock <= 5 ? Colors.orange.shade800 : Colors.green.shade700),
                    ),
                  ),
                );
              },
            ),
          ),
        ]);
      },
    );
  }

  Widget _pill(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(color: color, fontSize: 12)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.bold)),
      ]),
    );
  }
}

class StockHistoryPage extends StatelessWidget {
  const StockHistoryPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => store.stockLogs.isEmpty
          ? const Center(child: Text('Belum ada riwayat stok'))
          : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: store.stockLogs.length,
              itemBuilder: (_, i) {
                final l = store.stockLogs[i];
                final masuk = l.change > 0;
                return ListTile(
                  leading: Icon(masuk ? Icons.arrow_downward : Icons.arrow_upward, color: masuk ? Colors.green : Colors.red),
                  title: Text(l.productName),
                  subtitle: Text('${l.reason} • ${l.date.day}/${l.date.month}/${l.date.year} ${l.date.hour}:${l.date.minute.toString().padLeft(2, '0')}'),
                  trailing: Text('${masuk ? '+' : ''}${l.change}', style: TextStyle(fontWeight: FontWeight.bold, color: masuk ? Colors.green : Colors.red)),
                );
              },
            ),
    );
  }
}

class CustomerPage extends StatelessWidget {
  const CustomerPage({super.key});

  Future<void> editCustomer(BuildContext context, [Customer? c]) async {
    final n = TextEditingController(text: c?.name ?? '');
    final ph = TextEditingController(text: c?.phone ?? '');
    final ad = TextEditingController(text: c?.address ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(c == null ? 'Tambah Pelanggan' : 'Edit Pelanggan'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: n, decoration: const InputDecoration(labelText: 'Nama')),
          TextField(controller: ph, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'No. HP (opsional)')),
          TextField(controller: ad, decoration: const InputDecoration(labelText: 'Alamat (opsional)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true || n.text.trim().isEmpty) return;
    if (c == null) {
      store.customers.add(Customer(id: DateTime.now().millisecondsSinceEpoch.toString(), name: n.text.trim(), phone: ph.text.trim(), address: ad.text.trim()));
    } else {
      c.name = n.text.trim();
      c.phone = ph.text.trim();
      c.address = ad.text.trim();
    }
    store.saveCustomers();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => editCustomer(context),
          icon: const Icon(Icons.person_add_alt),
          label: const Text('Pelanggan'),
        ),
        body: store.customers.isEmpty
            ? const Center(child: Text('Belum ada data pelanggan'))
            : ListView.builder(
                padding: const EdgeInsets.only(bottom: 90),
                itemCount: store.customers.length,
                itemBuilder: (_, i) {
                  final c = store.customers[i];
                  final total = store.orders.where((o) => o.name.toLowerCase() == c.name.toLowerCase()).fold(0, (a, o) => a + o.total);
                  return ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                    title: Text(c.name),
                    subtitle: Text('${c.phone.isEmpty ? 'Tanpa HP' : c.phone} • Total belanja ${rp(total)}'),
                    onTap: () => editCustomer(context, c),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        store.customers.remove(c);
                        store.saveCustomers();
                      },
                    ),
                  );
                },
              ),
      ),
    );
  }
}
