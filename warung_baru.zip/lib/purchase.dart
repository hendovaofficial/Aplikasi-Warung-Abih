import 'package:flutter/material.dart';
import 'data.dart';

class PurchasePage extends StatefulWidget {
  const PurchasePage({super.key});
  @override
  State<PurchasePage> createState() => _PurchasePageState();
}

class _PurchasePageState extends State<PurchasePage> {
  Product? selected;
  String query = '';
  final searchC = TextEditingController();
  final qtyC = TextEditingController();
  final costC = TextEditingController();
  final supplierC = TextEditingController();

  Future<void> simpan() async {
    if (selected == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cari dan pilih produk dulu')));
      return;
    }
    final qty = int.tryParse(qtyC.text.trim()) ?? 0;
    final cost = int.tryParse(costC.text.trim()) ?? 0;
    if (qty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Jumlah harus lebih dari 0')));
      return;
    }
    final p = selected!;
    p.stock += qty;
    if (cost > 0) p.costPrice = cost;
    final supplier = supplierC.text.trim();
    final keterangan = supplier.isEmpty ? 'Pembelian barang' : 'Pembelian dari $supplier';
    store.logStock(p.name, qty, keterangan);
    store.save();
    final totalBiaya = (cost > 0 ? cost : p.costPrice) * qty;
    if (totalBiaya > 0) {
      store.addCash('keluar', totalBiaya, '$keterangan (${p.name} x$qty)');
    }
    setState(() {
      selected = null;
      searchC.clear();
      query = '';
      qtyC.clear();
      costC.clear();
      supplierC.clear();
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pembelian tersimpan, stok bertambah')));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final hasil = query.trim().length >= 3
            ? store.products.where((p) => p.name.toLowerCase().contains(query.trim().toLowerCase())).toList()
            : <Product>[];
        final riwayat = store.stockLogs.where((l) => l.change > 0).toList();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Catat Barang Masuk', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            if (selected == null) ...[
              TextField(
                controller: searchC,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Ketik min. 3 huruf nama barang...',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                onChanged: (v) => setState(() => query = v),
              ),
              const SizedBox(height: 8),
              if (query.trim().length >= 3 && hasil.isEmpty) const Text('Produk tidak ditemukan', style: TextStyle(color: Colors.grey)),
              ...hasil.map((p) => Card(
                    margin: const EdgeInsets.only(bottom: 6),
                    child: ListTile(
                      title: Text(p.name),
                      subtitle: Text('${p.category} • Stok ${p.stock} • Modal ${rp(p.costPrice)}'),
                      trailing: FilledButton.tonal(
                        onPressed: () => setState(() {
                          selected = p;
                          costC.text = p.costPrice == 0 ? '' : p.costPrice.toString();
                        }),
                        child: const Text('Pilih'),
                      ),
                    ),
                  )),
            ] else ...[
              Card(
                color: Colors.green.shade50,
                child: ListTile(
                  title: Text(selected!.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${selected!.category} • Stok saat ini ${selected!.stock}'),
                  trailing: TextButton(
                    onPressed: () => setState(() {
                      selected = null;
                      searchC.clear();
                      query = '';
                    }),
                    child: const Text('Ganti'),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(controller: qtyC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Jumlah masuk', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: costC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga beli per satuan (update harga modal)', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: supplierC, decoration: const InputDecoration(labelText: 'Nama supplier / toko grosir (opsional)', border: OutlineInputBorder())),
              const SizedBox(height: 16),
              FilledButton.icon(icon: const Icon(Icons.save_outlined), label: const Text('Simpan Pembelian'), onPressed: simpan),
            ],
            const SizedBox(height: 24),
            const Text('Riwayat Pembelian', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            if (riwayat.isEmpty) const Text('Belum ada pembelian tercatat'),
            ...riwayat.take(30).map((l) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.arrow_downward, color: Colors.green),
                  title: Text('${l.productName} +${l.change}'),
                  subtitle: Text('${l.reason} • ${l.date.day}/${l.date.month}/${l.date.year}'),
                )),
          ],
        );
      },
    );
  }
}
