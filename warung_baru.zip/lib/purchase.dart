import 'package:flutter/material.dart';
import 'data.dart';

class PurchasePage extends StatefulWidget {
  const PurchasePage({super.key});
  @override
  State<PurchasePage> createState() => _PurchasePageState();
}

class _PurchasePageState extends State<PurchasePage> {
  Product? selected;
  final qtyC = TextEditingController();
  final costC = TextEditingController();
  final supplierC = TextEditingController();

  Future<void> simpan() async {
    if (selected == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pilih produk dulu')));
      return;
    }
    final qty = int.tryParse(qtyC.text.trim()) ?? 0;
    final cost = int.tryParse(costC.text.trim()) ?? 0;
    if (qty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Jumlah harus lebih dari 0')));
      return;
    }
    final p = selected!;
    p.stock += qty;
    if (cost > 0) p.costPrice = cost;
    final supplier = supplierC.text.trim();
    store.logStock(p.name, qty, supplier.isEmpty ? 'Pembelian barang' : 'Pembelian dari $supplier');
    store.save();
    setState(() {
      selected = null;
      qtyC.clear();
      costC.clear();
      supplierC.clear();
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pembelian tersimpan, stok bertambah')));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final riwayat = store.stockLogs.where((l) => l.change > 0).toList();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Catat Barang Masuk', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            DropdownButtonFormField<Product>(
              value: selected,
              decoration: const InputDecoration(labelText: 'Pilih produk', border: OutlineInputBorder()),
              items: store.products.map((p) => DropdownMenuItem(value: p, child: Text(p.name))).toList(),
              onChanged: (v) => setState(() => selected = v),
            ),
            const SizedBox(height: 12),
            TextField(controller: qtyC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Jumlah masuk', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: costC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga beli per satuan (opsional, update harga modal)', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: supplierC, decoration: const InputDecoration(labelText: 'Nama supplier / toko grosir (opsional)', border: OutlineInputBorder())),
            const SizedBox(height: 16),
            FilledButton.icon(icon: const Icon(Icons.save_outlined), label: const Text('Simpan Pembelian'), onPressed: simpan),
            const SizedBox(height: 24),
            const Text('Riwayat Pembelian', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            if (riwayat.isEmpty) const Text('Belum ada pembelian tercatat'),
            ...riwayat.take(30).map((l) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.arrow_downward, color: Colors.green),
                  title: Text('${l.productName} +${l.change}'),
                  subtitle: Text('${l.reason} • ${l.date.day}/${l.date.month}/${l.date.year}'),
                )),
          ],
        );
      },
    );
  }
}
