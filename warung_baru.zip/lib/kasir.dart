import 'package:flutter/material.dart';
import 'data.dart';

class KasirPage extends StatefulWidget {
  const KasirPage({super.key});
  @override
  State<KasirPage> createState() => _KasirPageState();
}

class _KasirPageState extends State<KasirPage> {
  final Map<String, int> kasirCart = {};
  String query = '';

  int get total {
    int t = 0;
    kasirCart.forEach((id, q) {
      final p = store.byId(id);
      if (p != null) t += p.price * q;
    });
    return t;
  }

  void add(Product p) {
    if ((kasirCart[p.id] ?? 0) >= p.stock) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Stok tidak cukup')));
      return;
    }
    setState(() => kasirCart[p.id] = (kasirCart[p.id] ?? 0) + 1);
  }

  void sub(Product p) {
    final q = (kasirCart[p.id] ?? 0) - 1;
    setState(() {
      if (q <= 0) {
        kasirCart.remove(p.id);
      } else {
        kasirCart[p.id] = q;
      }
    });
  }

  Future<void> bayar() async {
    if (kasirCart.isEmpty) return;
    final bayarC = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setS) {
          final bayar = int.tryParse(bayarC.text) ?? 0;
          final kembali = bayar - total;
          return AlertDialog(
            title: const Text('Bayar Tunai'),
            content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Total belanja: ${rp(total)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 12),
              TextField(
                controller: bayarC,
                keyboardType: TextInputType.number,
                autofocus: true,
                decoration: const InputDecoration(labelText: 'Uang diterima'),
                onChanged: (_) => setS(() {}),
              ),
              const SizedBox(height: 8),
              Text(
                kembali >= 0 ? 'Kembalian: ${rp(kembali)}' : 'Kurang: ${rp(-kembali)}',
                style: TextStyle(color: kembali >= 0 ? Colors.green.shade700 : Colors.red, fontWeight: FontWeight.bold),
              ),
            ]),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
              FilledButton(
                onPressed: bayar >= total ? () => Navigator.pop(d, true) : null,
                child: const Text('Selesai'),
              ),
            ],
          );
        },
      ),
    );
    if (ok != true) return;

    final items = kasirCart.entries.map((e) {
      final p = store.byId(e.key)!;
      return OrderItem(p.name, p.price, e.value, p.unit, p.costPrice);
    }).toList();
    final order = CustomerOrder(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: 'Pembeli Langsung',
      address: 'Beli di toko',
      notes: '',
      items: items,
      date: DateTime.now(),
      status: 'Selesai',
      channel: 'kasir',
    );
    store.orders.insert(0, order);
    for (final e in kasirCart.entries) {
      final p = store.byId(e.key);
      if (p != null) p.stock = (p.stock - e.value).clamp(0, 1 << 30);
    }
    store.saveOrders();
    store.save();
    setState(() => kasirCart.clear());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Transaksi tersimpan')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        var list = store.products.where((p) => p.stock > 0).toList();
        if (query.isNotEmpty) {
          list = list.where((p) => p.name.toLowerCase().contains(query.toLowerCase())).toList();
        }
        return Scaffold(
          body: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: TextField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Cari barang untuk dijual...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  isDense: true,
                ),
                onChanged: (v) => setState(() => query = v),
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 90),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final p = list[i];
                  final q = kasirCart[p.id] ?? 0;
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    child: ListTile(
                      title: Text(p.name),
                      subtitle: Text('${rp(p.price)} / ${p.unit} • Stok ${p.stock}'),
                      trailing: q == 0
                          ? FilledButton.tonal(onPressed: () => add(p), child: const Text('Tambah'))
                          : Row(mainAxisSize: MainAxisSize.min, children: [
                              IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => sub(p)),
                              Text('$q'),
                              IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => add(p)),
                            ]),
                    ),
                  );
                },
              ),
            ),
          ]),
          bottomNavigationBar: kasirCart.isEmpty
              ? null
              : SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: FilledButton.icon(
                      icon: const Icon(Icons.point_of_sale),
                      label: Text('Bayar • ${rp(total)}'),
                      onPressed: bayar,
                    ),
                  ),
                ),
        );
      },
    );
  }
}
