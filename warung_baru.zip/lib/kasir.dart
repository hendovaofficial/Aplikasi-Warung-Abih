import 'package:flutter/material.dart';
import 'data.dart';
import 'receipt.dart';
import 'admin.dart';

class KasirPage extends StatefulWidget {
  const KasirPage({super.key});
  @override
  State<KasirPage> createState() => _KasirPageState();
}

class _KasirPageState extends State<KasirPage> {
  final Map<String, int> kasirCart = {};
  String query = '';
  String category = 'Semua';

  int get total {
    int t = 0;
    kasirCart.forEach((id, q) {
      final p = store.byId(id);
      if (p != null) t += p.price * q;
    });
    return t;
  }

  void add(Product p) {
    if ((kasirCart[p.id] ?? 0) >= p.stock) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Stok tidak cukup')));
      return;
    }
    setState(() => kasirCart[p.id] = (kasirCart[p.id] ?? 0) + 1);
  }

  void sub(Product p) {
    final q = (kasirCart[p.id] ?? 0) - 1;
    setState(() {
      if (q <= 0) {
        kasirCart.remove(p.id);
      } else {
        kasirCart[p.id] = q;
      }
    });
  }

  Future<void> bayar() async {
    if (kasirCart.isEmpty) return;
    final bayarC = TextEditingController();
    final namaC = TextEditingController(text: 'Pembeli Langsung');
    String metode = 'Tunai';
    bool hutang = false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setS) {
          final bayarDiisi = int.tryParse(bayarC.text) ?? 0;
          final kembali = bayarDiisi - total;
          final bisaSelesai = hutang ? (bayarDiisi >= 0 && bayarDiisi <= total) : bayarDiisi >= total;
          return AlertDialog(
            title: const Text('Pembayaran'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Total belanja: ${rp(total)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 12),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'Tunai', label: Text('Tunai'), icon: Icon(Icons.payments_outlined)),
                    ButtonSegment(value: 'QRIS', label: Text('QRIS'), icon: Icon(Icons.qr_code)),
                  ],
                  selected: {metode},
                  onSelectionChanged: (s) => setS(() => metode = s.first),
                ),
                const SizedBox(height: 12),
                if (metode == 'QRIS' && store.qrisImageUrl.isNotEmpty)
                  Center(
                    child: Image.network(store.qrisImageUrl, height: 160, errorBuilder: (_, __, ___) => const Text('Gagal memuat gambar QRIS')),
                  ),
                if (metode == 'QRIS' && store.qrisImageUrl.isEmpty)
                  const Text('Tunjukkan QRIS toko ke pelanggan (belum ada gambar QRIS di Pengaturan).', style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 12),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: hutang,
                  title: const Text('Catat sebagai hutang (belum lunas)'),
                  onChanged: (v) => setS(() => hutang = v ?? false),
                ),
                if (hutang)
                  TextField(controller: namaC, decoration: const InputDecoration(labelText: 'Nama pembeli (untuk catatan hutang)')),
                const SizedBox(height: 8),
                TextField(
                  controller: bayarC,
                  keyboardType: TextInputType.number,
                  autofocus: true,
                  decoration: InputDecoration(labelText: hutang ? 'Dibayar sekarang (boleh 0)' : 'Uang diterima'),
                  onChanged: (_) => setS(() {}),
                ),
                const SizedBox(height: 8),
                if (!hutang)
                  Text(
                    kembali >= 0 ? 'Kembalian: ${rp(kembali)}' : 'Kurang: ${rp(-kembali)}',
                    style: TextStyle(color: kembali >= 0 ? Colors.green.shade700 : Colors.red, fontWeight: FontWeight.bold),
                  )
                else
                  Text('Sisa hutang: ${rp((total - bayarDiisi).clamp(0, total))}', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
              FilledButton(onPressed: bisaSelesai ? () => Navigator.pop(d, true) : null, child: const Text('Selesai')),
            ],
          );
        },
      ),
    );
    if (ok != true) return;

    final items = kasirCart.entries.map((e) {
      final p = store.byId(e.key)!;
      return OrderItem(p.name, p.price, e.value, p.unit, p.costPrice);
    }).toList();
    final dibayar = hutang ? (int.tryParse(bayarC.text) ?? 0).clamp(0, total) : total;
    final order = CustomerOrder(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: hutang ? (namaC.text.trim().isEmpty ? 'Pembeli Langsung' : namaC.text.trim()) : 'Pembeli Langsung',
      address: 'Beli di toko',
      notes: '',
      items: items,
      date: DateTime.now(),
      status: 'Selesai',
      channel: 'kasir',
      paymentMethod: metode,
      paid: dibayar,
    );
    store.orders.insert(0, order);
    if (hutang && !store.customers.any((c) => c.name.toLowerCase() == order.name.toLowerCase())) {
      store.customers.add(Customer(id: order.id, name: order.name));
      store.saveCustomers();
    }
    for (final e in kasirCart.entries) {
      final p = store.byId(e.key);
      if (p != null) {
        p.stock = (p.stock - e.value).clamp(0, 1 << 30);
        store.logStock(p.name, -e.value, 'Penjualan kasir');
      }
    }
    store.saveOrders();
    store.save();
    if (dibayar > 0) {
      store.addCash('masuk', dibayar, 'Penjualan kasir - ${order.name}');
    }
    setState(() => kasirCart.clear());
    if (mounted) {
      await showReceipt(context, order);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        var list = store.products.where((p) => p.stock > 0).toList();
        if (category != 'Semua') list = list.where((p) => p.category == category).toList();
        if (query.isNotEmpty) {
          list = list.where((p) => p.name.toLowerCase().contains(query.toLowerCase())).toList();
        }
        final pesananBaru = store.orders.where((o) => o.channel == 'online' && o.status == 'Baru').length;
        return Scaffold(
          body: Column(children: [
            if (pesananBaru > 0)
              InkWell(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Daftar Pesanan')), body: const OrdersAdminPage(onlineOnly: true)))),
                child: Container(
                  width: double.infinity,
                  color: Colors.orange.shade50,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(children: [
                    const Icon(Icons.notifications_active_outlined, color: Colors.orange),
                    const SizedBox(width: 8),
                    Expanded(child: Text('$pesananBaru pesanan online baru menunggu diproses', style: const TextStyle(color: Colors.orange))),
                    const Icon(Icons.chevron_right, color: Colors.orange),
                  ]),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: TextField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Cari barang untuk dijual...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  isDense: true,
                ),
                onChanged: (v) => setState(() => query = v),
              ),
            ),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: store.categories.map((c) {
                  final sel = c == category;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(label: Text(c), selected: sel, onSelected: (_) => setState(() => category = c)),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 4),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 90),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final p = list[i];
                  final q = kasirCart[p.id] ?? 0;
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    child: ListTile(
                      title: Text(p.name),
                      subtitle: Text('${rp(p.price)} / ${p.unit} • Stok ${p.stock}'),
                      trailing: q == 0
                          ? FilledButton.tonal(onPressed: () => add(p), child: const Text('Tambah'))
                          : Row(mainAxisSize: MainAxisSize.min, children: [
                              IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => sub(p)),
                              Text('$q'),
                              IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => add(p)),
                            ]),
                    ),
                  );
                },
              ),
            ),
          ]),
          bottomNavigationBar: kasirCart.isEmpty
              ? null
              : SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: FilledButton.icon(
                      icon: const Icon(Icons.point_of_sale),
                      label: Text('Bayar • ${rp(total)}'),
                      onPressed: bayar,
                    ),
                  ),
                ),
        );
      },
    );
  }
}
