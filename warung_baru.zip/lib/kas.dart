import 'package:flutter/material.dart';
import 'data.dart';

Future<void> addCashDialog(BuildContext context, String type) async {
  final amountC = TextEditingController();
  final noteC = TextEditingController();
  final judul = type == 'masuk' ? 'Catat Pemasukan' : 'Catat Pengeluaran';
  final ok = await showDialog<bool>(
    context: context,
    builder: (d) => AlertDialog(
      title: Text(judul),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: amountC, keyboardType: TextInputType.number, autofocus: true, decoration: const InputDecoration(labelText: 'Jumlah (Rp)')),
        const SizedBox(height: 8),
        TextField(controller: noteC, decoration: const InputDecoration(labelText: 'Keterangan')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
      ],
    ),
  );
  if (ok != true) return;
  final amt = int.tryParse(amountC.text.trim()) ?? 0;
  if (amt <= 0) return;
  store.addCash(type, amt, noteC.text.trim().isEmpty ? (type == 'masuk' ? 'Pemasukan lain' : 'Pengeluaran lain') : noteC.text.trim());
}

class RekapKasPage extends StatelessWidget {
  const RekapKasPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(10)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Pemasukan', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  Text(rp(store.totalMasuk), style: TextStyle(color: Colors.green.shade800, fontWeight: FontWeight.bold, fontSize: 16)),
                ]),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(10)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Pengeluaran', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  Text(rp(store.totalKeluar), style: TextStyle(color: Colors.red.shade800, fontWeight: FontWeight.bold, fontSize: 16)),
                ]),
              ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(child: FilledButton.icon(icon: const Icon(Icons.arrow_downward), label: const Text('Pemasukan'), onPressed: () => addCashDialog(context, 'masuk'))),
            const SizedBox(width: 8),
            Expanded(child: FilledButton.tonalIcon(icon: const Icon(Icons.arrow_upward), label: const Text('Pengeluaran'), onPressed: () => addCashDialog(context, 'keluar'))),
          ]),
        ),
        const Divider(height: 24),
        Expanded(
          child: store.cashEntries.isEmpty
              ? const Center(child: Text('Belum ada catatan kas'))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: store.cashEntries.length,
                  itemBuilder: (_, i) {
                    final e = store.cashEntries[i];
                    final masuk = e.type == 'masuk';
                    return ListTile(
                      leading: Icon(masuk ? Icons.arrow_downward : Icons.arrow_upward, color: masuk ? Colors.green : Colors.red),
                      title: Text(e.note),
                      subtitle: Text('${e.date.day}/${e.date.month}/${e.date.year} ${e.date.hour}:${e.date.minute.toString().padLeft(2, '0')}'),
                      trailing: Text('${masuk ? '+' : '-'}${rp(e.amount)}', style: TextStyle(fontWeight: FontWeight.bold, color: masuk ? Colors.green : Colors.red)),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
