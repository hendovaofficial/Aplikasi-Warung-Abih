import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'data.dart';

String buildReceiptText(CustomerOrder o) {
  final b = StringBuffer();
  b.writeln('*${store.shop}*');
  if (store.address.isNotEmpty) b.writeln(store.address);
  b.writeln('------------------------------');
  b.writeln('${o.date.day}/${o.date.month}/${o.date.year} ${o.date.hour}:${o.date.minute.toString().padLeft(2, '0')}');
  b.writeln('Pelanggan: ${o.name}');
  b.writeln('------------------------------');
  for (final it in o.items) {
    b.writeln('${it.name}');
    b.writeln('  ${it.qty} ${it.unit} x ${rp(it.price)} = ${rp(it.subtotal)}');
  }
  b.writeln('------------------------------');
  b.writeln('Total     : ${rp(o.total)}');
  b.writeln('Metode    : ${o.paymentMethod}');
  b.writeln('Dibayar   : ${rp(o.paid)}');
  if (!o.lunas) b.writeln('Sisa hutang: ${rp(o.owing)}');
  b.writeln('------------------------------');
  b.writeln('Terima kasih sudah belanja!');
  return b.toString();
}

Future<void> showReceipt(BuildContext context, CustomerOrder o) async {
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (s) => Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(s).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Struk', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(s)),
          ]),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(10)),
            child: Text(
              buildReceiptText(o).replaceAll('*', ''),
              style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              icon: const Icon(Icons.ios_share),
              label: const Text('Bagikan Struk'),
              onPressed: () => Share.share(buildReceiptText(o)),
            ),
          ),
        ]),
      ),
    ),
  );
}
