import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'data.dart';
import 'admin.dart';

class ShopPage extends StatefulWidget {
  const ShopPage({super.key});
  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  String category = 'Semua';
  String query = '';

  Future<void> askPin() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('PIN Admin'),
        content: TextField(
          controller: c,
          obscureText: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: 'Masukkan PIN'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, c.text == store.pin), child: const Text('Masuk')),
        ],
      ),
    );
    if (!mounted) return;
    if (ok == true) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminHome()));
    } else if (ok == false) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN salah')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        var list = store.products.where((p) => p.active).toList();
        if (category != 'Semua') list = list.where((p) => p.category == category).toList();
        if (query.isNotEmpty) {
          list = list.where((p) => p.name.toLowerCase().contains(query.toLowerCase())).toList();
        }
        return Scaffold(
          appBar: AppBar(
            title: Text(store.shop),
            actions: [
              IconButton(icon: const Icon(Icons.receipt_long), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyOrdersPage()))),
              IconButton(icon: const Icon(Icons.admin_panel_settings_outlined), onPressed: askPin),
            ],
          ),
          body: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: TextField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Cari barang...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  isDense: true,
                ),
                onChanged: (v) => setState(() => query = v),
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: store.categories.map((c) {
                  final sel = c == category;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(c),
                      selected: sel,
                      onSelected: (_) => setState(() => category = c),
                    ),
                  );
                }).toList(),
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('Produk tidak ditemukan'))
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(8, 8, 8, 90),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 4),
                      itemBuilder: (_, i) {
                        final p = list[i];
                        final q = store.cart[p.id] ?? 0;
                        final habis = p.stock <= 0;
                        return Card(
                          margin: EdgeInsets.zero,
                          child: ListTile(
                            leading: CircleAvatar(
                              radius: 26,
                              backgroundColor: Colors.green.shade50,
                              backgroundImage: p.imageUrl.isNotEmpty ? NetworkImage(p.imageUrl) : null,
                              child: p.imageUrl.isEmpty ? const Icon(Icons.shopping_basket_outlined, color: Colors.green) : null,
                            ),
                            title: Text(p.name),
                            subtitle: Text('${rp(p.price)} / ${p.unit}${habis ? '  •  Stok habis' : '  •  Stok ${p.stock}'}'),
                            trailing: habis
                                ? const Text('Habis', style: TextStyle(color: Colors.red))
                                : q == 0
                                    ? FilledButton.tonal(onPressed: () => store.addToCart(p), child: const Text('Tambah'))
                                    : Row(mainAxisSize: MainAxisSize.min, children: [
                                        IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => store.subFromCart(p)),
                                        Text('$q', style: const TextStyle(fontSize: 16)),
                                        IconButton(
                                          icon: const Icon(Icons.add_circle_outline),
                                          onPressed: q < p.stock ? () => store.addToCart(p) : null,
                                        ),
                                      ]),
                          ),
                        );
                      },
                    ),
            ),
          ]),
          bottomNavigationBar: store.cartCount == 0
              ? null
              : SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: FilledButton.icon(
                      icon: const Icon(Icons.shopping_cart),
                      label: Text('Keranjang (${store.cartCount}) • ${rp(store.cartTotal)}'),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartPage())),
                    ),
                  ),
                ),
        );
      },
    );
  }
}

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  Future<void> checkout(BuildContext context) async {
    final nama = TextEditingController();
    final alamat = TextEditingController();
    final cat = TextEditingController();
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (s) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(s).viewInsets.bottom + 16),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Data Pengantaran', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(controller: nama, decoration: const InputDecoration(labelText: 'Nama')),
            TextField(controller: alamat, maxLines: 2, decoration: const InputDecoration(labelText: 'Alamat lengkap')),
            TextField(controller: cat, decoration: const InputDecoration(labelText: 'Catatan (opsional)')),
            const SizedBox(height: 12),
            Text('Total: ${rp(store.cartTotal)} (belum termasuk ongkir)'),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                icon: const Icon(Icons.send),
                label: const Text('Kirim Pesanan via WhatsApp'),
                onPressed: () async {
                  if (nama.text.trim().isEmpty || alamat.text.trim().isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nama dan alamat wajib diisi')));
                    return;
                  }
                  var num = store.wa.replaceAll(RegExp(r'\D'), '');
                  if (num.startsWith('0')) num = '62${num.substring(1)}';
                  if (num.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nomor WhatsApp toko belum diisi (menu admin)')));
                    return;
                  }
                  final items = store.cart.entries
                      .map((e) {
                        final p = store.byId(e.key)!;
                        return OrderItem(p.name, p.price, e.value, p.unit, p.costPrice);
                      })
                      .toList();
                  final order = CustomerOrder(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    name: nama.text.trim(),
                    address: alamat.text.trim(),
                    notes: cat.text.trim(),
                    items: items,
                    date: DateTime.now(),
                  );
                  store.orders.insert(0, order);
                  if (!store.customers.any((c) => c.name.toLowerCase() == order.name.toLowerCase())) {
                    store.customers.add(Customer(id: order.id, name: order.name, address: order.address));
                    store.saveCustomers();
                  }
                  for (final e in store.cart.entries) {
                    final p = store.byId(e.key);
                    if (p != null) {
                      p.stock = (p.stock - e.value).clamp(0, 1 << 30);
                      store.logStock(p.name, -e.value, 'Pesanan online');
                    }
                  }
                  store.saveOrders();
                  store.save();
                  store.clearCart();

                  final b = StringBuffer('Halo ${store.shop}, saya mau pesan:\n\n');
                  for (final it in items) {
                    b.writeln('- ${it.name} x${it.qty} ${it.unit} = ${rp(it.subtotal)}');
                  }
                  b.writeln('\nTotal: ${rp(order.total)} (belum termasuk ongkir)');
                  b.writeln('Nama: ${order.name}');
                  b.writeln('Alamat antar: ${order.address}');
                  if (order.notes.isNotEmpty) b.writeln('Catatan: ${order.notes}');
                  final uri = Uri.parse('https://wa.me/$num?text=${Uri.encodeComponent(b.toString())}');
                  if (context.mounted) Navigator.pop(context);
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                  if (context.mounted) Navigator.pop(context);
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Keranjang')),
        body: store.cart.isEmpty
            ? const Center(child: Text('Keranjang kosong'))
            : ListView(
                padding: const EdgeInsets.all(12),
                children: store.cart.entries.map((e) {
                  final p = store.byId(e.key)!;
                  return Card(
                    child: ListTile(
                      title: Text(p.name),
                      subtitle: Text('${rp(p.price)} x ${e.value} = ${rp(p.price * e.value)}'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => store.subFromCart(p)),
                        Text('${e.value}'),
                        IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => store.addToCart(p)),
                      ]),
                    ),
                  );
                }).toList(),
              ),
        bottomNavigationBar: store.cart.isEmpty
            ? null
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: FilledButton(
                    onPressed: () => checkout(context),
                    child: Text('Checkout • ${rp(store.cartTotal)}'),
                  ),
                ),
              ),
      ),
    );
  }
}

class MyOrdersPage extends StatelessWidget {
  const MyOrdersPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Riwayat Pesanan Saya')),
        body: store.orders.isEmpty
            ? const Center(child: Text('Belum ada pesanan'))
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: store.orders.length,
                itemBuilder: (_, i) {
                  final o = store.orders[i];
                  return Card(
                    child: ListTile(
                      title: Text('${o.name} • ${rp(o.total)}'),
                      subtitle: Text('${o.items.length} barang • ${o.date.day}/${o.date.month}/${o.date.year} • ${o.status}'),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
