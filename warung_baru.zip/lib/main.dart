import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

String rp(int n) => 'Rp${n.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => '.')}';

class Product {
  String name, unit;
  int price;
  Product(this.name, this.price, this.unit);
  Map<String, dynamic> toJson() => {'n': name, 'p': price, 'u': unit};
  factory Product.fromJson(Map<String, dynamic> j) => Product(j['n'], j['p'], j['u']);
}

class Store extends ChangeNotifier {
  late SharedPreferences sp;
  List<Product> products = [];
  String shop = 'Warung Abih', wa = '', pin = '1234';
  final Map<Product, int> cart = {};

  Future<void> load() async {
    sp = await SharedPreferences.getInstance();
    shop = sp.getString('shop') ?? shop;
    wa = sp.getString('wa') ?? '';
    pin = sp.getString('pin') ?? pin;
    final s = sp.getString('products');
    if (s == null) {
      products = [
        Product('Beras', 13000, 'kg'),
        Product('Minyak Goreng', 18000, 'liter'),
        Product('Gula Pasir', 17000, 'kg'),
        Product('Telur', 28000, 'kg'),
        Product('Mie Instan', 3500, 'bungkus'),
        Product('Kopi Sachet', 1500, 'pcs'),
      ];
    } else {
      products = (jsonDecode(s) as List).map((e) => Product.fromJson(e as Map<String, dynamic>)).toList();
    }
  }

  void save() {
    sp.setString('products', jsonEncode(products));
    sp.setString('shop', shop);
    sp.setString('wa', wa);
    sp.setString('pin', pin);
    notifyListeners();
  }

  void add(Product p) {
    cart[p] = (cart[p] ?? 0) + 1;
    notifyListeners();
  }

  void sub(Product p) {
    final q = (cart[p] ?? 0) - 1;
    if (q <= 0) {
      cart.remove(p);
    } else {
      cart[p] = q;
    }
    notifyListeners();
  }

  int get count => cart.values.fold(0, (a, b) => a + b);
  int get total => cart.entries.fold(0, (a, e) => a + e.key.price * e.value);
}

final store = Store();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  runApp(MaterialApp(
    title: 'Warung Abih',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: const Color(0xFF2E7D32), useMaterial3: true),
    home: const ShopPage(),
  ));
}

class ShopPage extends StatelessWidget {
  const ShopPage({super.key});

  Future<void> askPin(BuildContext context) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('PIN Admin'),
        content: TextField(controller: c, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'Masukkan PIN')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, c.text == store.pin), child: const Text('Masuk')),
        ],
      ),
    );
    if (!context.mounted) return;
    if (ok == true) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()));
    } else if (ok == false) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN salah')));
    }
  }

  void checkout(BuildContext context) {
    final nama = TextEditingController(), alamat = TextEditingController(), cat = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (s) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(s).viewInsets.bottom + 16),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Data Pengantaran', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(controller: nama, decoration: const InputDecoration(labelText: 'Nama')),
            TextField(controller: alamat, maxLines: 2, decoration: const InputDecoration(labelText: 'Alamat lengkap')),
            TextField(controller: cat, decoration: const InputDecoration(labelText: 'Catatan (opsional)')),
            const SizedBox(height: 12),
            Text('Total: ${rp(store.total)} (belum termasuk ongkir)'),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                icon: const Icon(Icons.send),
                label: const Text('Kirim via WhatsApp'),
                onPressed: () async {
                  if (nama.text.trim().isEmpty || alamat.text.trim().isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nama dan alamat wajib diisi')));
                    return;
                  }
                  var num = store.wa.replaceAll(RegExp(r'\D'), '');
                  if (num.startsWith('0')) num = '62${num.substring(1)}';
                  if (num.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nomor WhatsApp toko belum diisi (menu admin)')));
                    return;
                  }
                  final b = StringBuffer('Halo ${store.shop}, saya mau pesan:\n\n');
                  store.cart.forEach((p, q) => b.writeln('- ${p.name} x$q = ${rp(p.price * q)}'));
                  b.writeln('\nTotal: ${rp(store.total)} (belum termasuk ongkir)');
                  b.writeln('Nama: ${nama.text.trim()}');
                  b.writeln('Alamat antar: ${alamat.text.trim()}');
                  if (cat.text.trim().isNotEmpty) b.writeln('Catatan: ${cat.text.trim()}');
                  final uri = Uri.parse('https://wa.me/$num?text=${Uri.encodeComponent(b.toString())}');
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: Text(store.shop),
          actions: [IconButton(icon: const Icon(Icons.admin_panel_settings), onPressed: () => askPin(context))],
        ),
        body: store.products.isEmpty
            ? const Center(child: Text('Belum ada produk'))
            : ListView.separated(
                padding: const EdgeInsets.only(bottom: 90),
                itemCount: store.products.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final p = store.products[i];
                  final q = store.cart[p] ?? 0;
                  return ListTile(
                    title: Text(p.name),
                    subtitle: Text('${rp(p.price)} / ${p.unit}'),
                    trailing: q == 0
                        ? FilledButton.tonal(onPressed: () => store.add(p), child: const Text('Tambah'))
                        : Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => store.sub(p)),
                            Text('$q', style: const TextStyle(fontSize: 16)),
                            IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => store.add(p)),
                          ]),
                  );
                },
              ),
        bottomNavigationBar: store.count == 0
            ? null
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: FilledButton.icon(
                    icon: const Icon(Icons.shopping_cart),
                    label: Text('Pesan (${store.count} barang) • ${rp(store.total)}'),
                    onPressed: () => checkout(context),
                  ),
                ),
              ),
      ),
    );
  }
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});

  Future<void> editProduct(BuildContext context, [Product? p]) async {
    final n = TextEditingController(text: p?.name ?? '');
    final pr = TextEditingController(text: p?.price.toString() ?? '');
    final u = TextEditingController(text: p?.unit ?? 'pcs');
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(p == null ? 'Tambah Produk' : 'Edit Produk'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: n, decoration: const InputDecoration(labelText: 'Nama barang')),
          TextField(controller: pr, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga')),
          TextField(controller: u, decoration: const InputDecoration(labelText: 'Satuan (kg, liter, pcs)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true || n.text.trim().isEmpty) return;
    final harga = int.tryParse(pr.text.trim()) ?? 0;
    if (p == null) {
      store.products.add(Product(n.text.trim(), harga, u.text.trim()));
    } else {
      p.name = n.text.trim();
      p.price = harga;
      p.unit = u.text.trim();
    }
    store.save();
  }

  Future<void> settings(BuildContext context) async {
    final s = TextEditingController(text: store.shop);
    final w = TextEditingController(text: store.wa);
    final pn = TextEditingController(text: store.pin);
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Pengaturan Toko'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: s, decoration: const InputDecoration(labelText: 'Nama toko')),
          TextField(controller: w, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'No. WhatsApp (08xx / 628xx)')),
          TextField(controller: pn, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'PIN admin')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true) return;
    store.shop = s.text.trim().isEmpty ? store.shop : s.text.trim();
    store.wa = w.text.trim();
    store.pin = pn.text.trim().isEmpty ? store.pin : pn.text.trim();
    store.save();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: const Text('Admin'),
          actions: [IconButton(icon: const Icon(Icons.settings), onPressed: () => settings(context))],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => editProduct(context),
          icon: const Icon(Icons.add),
          label: const Text('Produk'),
        ),
        body: ListView.builder(
          padding: const EdgeInsets.only(bottom: 90),
          itemCount: store.products.length,
          itemBuilder: (_, i) {
            final p = store.products[i];
            return ListTile(
              title: Text(p.name),
              subtitle: Text('${rp(p.price)} / ${p.unit}'),
              onTap: () => editProduct(context, p),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () {
                  store.cart.remove(p);
                  store.products.remove(p);
                  store.save();
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
