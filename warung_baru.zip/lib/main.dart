import 'package:flutter/material.dart';
import 'data.dart';
import 'customer.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  runApp(const WarungApp());
}

class WarungApp extends StatelessWidget {
  const WarungApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Warung Abih',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: const Color(0xFF2E7D32), useMaterial3: true),
      home: const ShopPage(),
    );
  }
}
