import 'package:flutter/material.dart';
import 'data.dart';

class AdminHome extends StatelessWidget {
  const AdminHome({super.key});
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Admin Warung'),
          bottom: const TabBar(tabs: [
            Tab(text: 'Produk', icon: Icon(Icons.inventory_2_outlined)),
            Tab(text: 'Pesanan', icon: Icon(Icons.receipt_long_outlined)),
            Tab(text: 'Laporan', icon: Icon(Icons.bar_chart)),
            Tab(text: 'Pengaturan', icon: Icon(Icons.settings_outlined)),
          ]),
        ),
        body: const TabBarView(children: [
          ProductAdminPage(),
          OrdersAdminPage(),
          ReportPage(),
          SettingsPage(),
        ]),
      ),
    );
  }
}

class ProductAdminPage extends StatelessWidget {
  const ProductAdminPage({super.key});

  Future<void> editProduct(BuildContext context, [Product? p]) async {
    final n = TextEditingController(text: p?.name ?? '');
    final pr = TextEditingController(text: p?.price.toString() ?? '');
    final st = TextEditingController(text: p?.stock.toString() ?? '');
    final u = TextEditingController(text: p?.unit ?? 'pcs');
    final cat = TextEditingController(text: p?.category ?? 'Umum');
    final d = TextEditingController(text: p?.desc ?? '');
    final img = TextEditingController(text: p?.imageUrl ?? '');
    bool active = p?.active ?? true;

    final ok = await showDialog<bool>(
      context: context,
      builder: (d2) => StatefulBuilder(
        builder: (d2, setS) => AlertDialog(
          title: Text(p == null ? 'Tambah Produk' : 'Edit Produk'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: n, decoration: const InputDecoration(labelText: 'Nama barang')),
              TextField(controller: pr, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga')),
              TextField(controller: st, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stok')),
              TextField(controller: u, decoration: const InputDecoration(labelText: 'Satuan (kg, liter, pcs)')),
              TextField(controller: cat, decoration: const InputDecoration(labelText: 'Kategori')),
              TextField(controller: d, maxLines: 2, decoration: const InputDecoration(labelText: 'Deskripsi (opsional)')),
              TextField(controller: img, decoration: const InputDecoration(labelText: 'URL foto (opsional)')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Produk aktif'),
                subtitle: const Text('Tampil ke pelanggan'),
                value: active,
                onChanged: (v) => setS(() => active = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d2, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(d2, true), child: const Text('Simpan')),
          ],
        ),
      ),
    );
    if (ok != true || n.text.trim().isEmpty) return;
    final harga = int.tryParse(pr.text.trim()) ?? 0;
    final stok = int.tryParse(st.text.trim()) ?? 0;
    if (p == null) {
      store.products.add(Product(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: n.text.trim(),
        price: harga,
        unit: u.text.trim().isEmpty ? 'pcs' : u.text.trim(),
        category: cat.text.trim().isEmpty ? 'Umum' : cat.text.trim(),
        stock: stok,
        desc: d.text.trim(),
        imageUrl: img.text.trim(),
        active: active,
      ));
    } else {
      p.name = n.text.trim();
      p.price = harga;
      p.stock = stok;
      p.unit = u.text.trim().isEmpty ? 'pcs' : u.text.trim();
      p.category = cat.text.trim().isEmpty ? 'Umum' : cat.text.trim();
      p.desc = d.text.trim();
      p.imageUrl = img.text.trim();
      p.active = active;
    }
    store.save();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => editProduct(context),
          icon: const Icon(Icons.add),
          label: const Text('Produk'),
        ),
        body: store.products.isEmpty
            ? const Center(child: Text('Belum ada produk'))
            : ListView.builder(
                padding: const EdgeInsets.only(bottom: 90),
                itemCount: store.products.length,
                itemBuilder: (_, i) {
                  final p = store.products[i];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: p.active ? Colors.green.shade50 : Colors.grey.shade300,
                      backgroundImage: p.imageUrl.isNotEmpty ? NetworkImage(p.imageUrl) : null,
                      child: p.imageUrl.isEmpty ? Icon(Icons.shopping_basket_outlined, color: p.active ? Colors.green : Colors.grey) : null,
                    ),
                    title: Text(p.name),
                    subtitle: Text('${rp(p.price)} / ${p.unit} • Stok ${p.stock} • ${p.category}${p.active ? '' : ' • nonaktif'}'),
                    onTap: () => editProduct(context, p),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        store.products.remove(p);
                        store.save();
                      },
                    ),
                  );
                },
              ),
      ),
    );
  }
}

class OrdersAdminPage extends StatelessWidget {
  const OrdersAdminPage({super.key});
  static const statuses = ['Baru', 'Diproses', 'Diantar', 'Selesai', 'Dibatalkan'];

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => store.orders.isEmpty
          ? const Center(child: Text('Belum ada pesanan masuk'))
          : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: store.orders.length,
              itemBuilder: (_, i) {
                final o = store.orders[i];
                return Card(
                  child: ExpansionTile(
                    title: Text('${o.name} • ${rp(o.total)}'),
                    subtitle: Text('${o.date.day}/${o.date.month}/${o.date.year} ${o.date.hour}:${o.date.minute.toString().padLeft(2, '0')}'),
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          ...o.items.map((it) => Text('• ${it.name} x${it.qty} ${it.unit} = ${rp(it.subtotal)}')),
                          const SizedBox(height: 6),
                          Text('Alamat: ${o.address}'),
                          if (o.notes.isNotEmpty) Text('Catatan: ${o.notes}'),
                          const SizedBox(height: 8),
                          DropdownButton<String>(
                            value: o.status,
                            items: statuses.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                            onChanged: (v) {
                              if (v == null) return;
                              o.status = v;
                              store.saveOrders();
                            },
                          ),
                          const SizedBox(height: 8),
                        ]),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

class ReportPage extends StatelessWidget {
  const ReportPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final now = DateTime.now();
        final today = store.orders.where((o) => o.date.year == now.year && o.date.month == now.month && o.date.day == now.day);
        final month = store.orders.where((o) => o.date.year == now.year && o.date.month == now.month);
        final selesai = store.orders.where((o) => o.status != 'Dibatalkan');
        int sum(Iterable<CustomerOrder> l) => l.fold(0, (a, o) => a + o.total);

        final Map<String, int> perProduk = {};
        for (final o in selesai) {
          for (final it in o.items) {
            perProduk[it.name] = (perProduk[it.name] ?? 0) + it.qty;
          }
        }
        final top = perProduk.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(children: [
              Expanded(child: _StatCard(title: 'Omzet Hari Ini', value: rp(sum(today)), sub: '${today.length} pesanan')),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Omzet Bulan Ini', value: rp(sum(month)), sub: '${month.length} pesanan')),
            ]),
            const SizedBox(height: 12),
            _StatCard(title: 'Total Pesanan Tercatat', value: '${store.orders.length}', sub: 'sejak aplikasi dipasang'),
            const SizedBox(height: 20),
            const Text('Produk Terlaris', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            if (top.isEmpty) const Text('Belum ada data penjualan'),
            ...top.take(10).map((e) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(e.key),
                  trailing: Text('${e.value} terjual'),
                )),
          ],
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title, value, sub;
  const _StatCard({required this.title, required this.value, required this.sub});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text(sub, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        ]),
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = TextEditingController(text: store.shop);
    final w = TextEditingController(text: store.wa);
    final pn = TextEditingController(text: store.pin);
    final ad = TextEditingController(text: store.address);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(controller: s, decoration: const InputDecoration(labelText: 'Nama toko')),
        const SizedBox(height: 12),
        TextField(controller: w, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'No. WhatsApp (08xx atau 628xx)')),
        const SizedBox(height: 12),
        TextField(controller: ad, maxLines: 2, decoration: const InputDecoration(labelText: 'Alamat toko')),
        const SizedBox(height: 12),
        TextField(controller: pn, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'PIN admin')),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () {
            store.shop = s.text.trim().isEmpty ? store.shop : s.text.trim();
            store.wa = w.text.trim();
            store.address = ad.text.trim();
            store.pin = pn.text.trim().isEmpty ? store.pin : pn.text.trim();
            store.save();
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pengaturan disimpan')));
          },
          child: const Text('Simpan Pengaturan'),
        ),
      ],
    );
  }
}
