import 'package:flutter/material.dart';
import 'data.dart';
import 'kasir.dart';
import 'inventory.dart';
import 'categories.dart';
import 'purchase.dart';
import 'debt.dart';
import 'receipt.dart';
import 'laporan_lanjutan.dart';
import 'kas.dart';
import 'karyawan.dart';

void _openPage(BuildContext context, String title, Widget page) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: Text(title)), body: page)));
}

class AdminHome extends StatelessWidget {
  const AdminHome({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final now = DateTime.now();
        final validToday = store.orders.where((o) =>
            o.status != 'Dibatalkan' && o.date.year == now.year && o.date.month == now.month && o.date.day == now.day);
        final omzetHariIni = validToday.fold(0, (a, o) => a + o.total);
        final labaHariIni = validToday.fold(0, (a, o) => a + o.profit);
        final pesananBaru = store.orders.where((o) => o.channel == 'online' && o.status == 'Baru').length;
        final jumlahHutang = store.orders.where((o) => !o.lunas).length;

        final menu = <_MenuItem>[
          _MenuItem('Kasir', Icons.shopping_cart_outlined, () => _openPage(context, 'Kasir', const KasirPage())),
          _MenuItem('Produk', Icons.inventory_2_outlined, () => _openPage(context, 'Produk', const ProductAdminPage())),
          _MenuItem('Daftar Pesanan', Icons.receipt_long_outlined, () => _openPage(context, 'Daftar Pesanan', const OrdersAdminPage(onlineOnly: true)), badge: pesananBaru),
          _MenuItem('Riwayat Penjualan', Icons.history, () => _openPage(context, 'Riwayat Penjualan', const OrdersAdminPage())),
          _MenuItem('Pelanggan', Icons.people_outline, () => _openPage(context, 'Pelanggan', const CustomerPage())),
          _MenuItem('Karyawan', Icons.badge_outlined, () => _openPage(context, 'Karyawan', const EmployeePage())),
          _MenuItem('Laporan', Icons.bar_chart, () => _openPage(context, 'Laporan', const ReportPage())),
          _MenuItem('Pengaturan', Icons.settings_outlined, () => _openPage(context, 'Pengaturan', const SettingsPage())),
          _MenuItem('Kategori', Icons.sell_outlined, () => _openPage(context, 'Kategori Barang', const CategoryPage())),
          _MenuItem('Pembelian', Icons.local_shipping_outlined, () => _openPage(context, 'Pembelian Barang', const PurchasePage())),
          _MenuItem('Gudang', Icons.warehouse_outlined, () => _openPage(context, 'Gudang', const GudangPage())),
          _MenuItem('Hutang', Icons.credit_card_outlined, () => _openPage(context, 'Hutang / Piutang', const DebtPage()), badge: jumlahHutang),
        ];

        return Scaffold(
          appBar: AppBar(title: const Text('Dasbor')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.green.shade50, Colors.white]),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.green.shade100),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Saldo Kas', style: TextStyle(color: Colors.grey)),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.account_balance_wallet_outlined, size: 16),
                      label: const Text('Rekap Kas'),
                      onPressed: () => _openPage(context, 'Rekap Kas', const RekapKasPage()),
                    ),
                  ]),
                  const SizedBox(height: 4),
                  Text(rp(store.saldoKas), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text('Omzet hari ini ${rp(omzetHariIni)} • Laba ${rp(labaHariIni)}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                  const SizedBox(height: 14),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.arrow_downward),
                        label: const Text('Pemasukan'),
                        onPressed: () => addCashDialog(context, 'masuk'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.arrow_upward),
                        label: const Text('Pengeluaran'),
                        onPressed: () => addCashDialog(context, 'keluar'),
                      ),
                    ),
                  ]),
                ]),
              ),
              const SizedBox(height: 20),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.95,
                children: menu.map((m) => _MenuTile(item: m)).toList(),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _MenuItem {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final int badge;
  _MenuItem(this.label, this.icon, this.onTap, {this.badge = 0});
}

class _MenuTile extends StatelessWidget {
  final _MenuItem item;
  const _MenuTile({required this.item});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: item.onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Stack(children: [
          Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(item.icon, color: Colors.green.shade700, size: 28),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(item.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12.5)),
              ),
            ]),
          ),
          if (item.badge > 0)
            Positioned(
              top: 6,
              right: 6,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(10)),
                child: Text('${item.badge}', style: const TextStyle(color: Colors.white, fontSize: 11)),
              ),
            ),
        ]),
      ),
    );
  }
}

class ProductAdminPage extends StatelessWidget {
  const ProductAdminPage({super.key});

  Future<void> editProduct(BuildContext context, [Product? p]) async {
    final n = TextEditingController(text: p?.name ?? '');
    final pr = TextEditingController(text: p?.price.toString() ?? '');
    final cp = TextEditingController(text: p?.costPrice == null || p?.costPrice == 0 ? '' : p!.costPrice.toString());
    final st = TextEditingController(text: p?.stock.toString() ?? '');
    final u = TextEditingController(text: p?.unit ?? 'pcs');
    final cat = TextEditingController(text: p?.category ?? 'Umum');
    final d = TextEditingController(text: p?.desc ?? '');
    final img = TextEditingController(text: p?.imageUrl ?? '');
    final sku = TextEditingController(text: p?.sku ?? '');
    final bc = TextEditingController(text: p?.barcode ?? '');
    bool active = p?.active ?? true;

    final ok = await showDialog<bool>(
      context: context,
      builder: (d2) => StatefulBuilder(
        builder: (d2, setS) => AlertDialog(
          title: Text(p == null ? 'Tambah Produk' : 'Edit Produk'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: n, decoration: const InputDecoration(labelText: 'Nama barang')),
              TextField(controller: pr, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga jual')),
              TextField(controller: cp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga modal (untuk laporan laba)')),
              TextField(controller: st, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stok')),
              TextField(controller: u, decoration: const InputDecoration(labelText: 'Satuan (kg, liter, pcs)')),
              TextField(controller: cat, decoration: const InputDecoration(labelText: 'Kategori')),
              TextField(controller: sku, decoration: const InputDecoration(labelText: 'SKU (opsional)')),
              TextField(controller: bc, decoration: const InputDecoration(labelText: 'Barcode (opsional)')),
              TextField(controller: d, maxLines: 2, decoration: const InputDecoration(labelText: 'Deskripsi (opsional)')),
              TextField(controller: img, decoration: const InputDecoration(labelText: 'URL foto (opsional)')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Produk aktif'),
                subtitle: const Text('Tampil ke pelanggan'),
                value: active,
                onChanged: (v) => setS(() => active = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d2, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(d2, true), child: const Text('Simpan')),
          ],
        ),
      ),
    );
    if (ok != true || n.text.trim().isEmpty) return;
    final harga = int.tryParse(pr.text.trim()) ?? 0;
    final modal = int.tryParse(cp.text.trim()) ?? 0;
    final stok = int.tryParse(st.text.trim()) ?? 0;
    if (p == null) {
      store.products.add(Product(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: n.text.trim(),
        price: harga,
        costPrice: modal,
        unit: u.text.trim().isEmpty ? 'pcs' : u.text.trim(),
        category: cat.text.trim().isEmpty ? 'Umum' : cat.text.trim(),
        stock: stok,
        desc: d.text.trim(),
        imageUrl: img.text.trim(),
        active: active,
        sku: sku.text.trim(),
        barcode: bc.text.trim(),
      ));
      if (stok != 0) store.logStock(n.text.trim(), stok, 'Produk baru');
    } else {
      p.name = n.text.trim();
      p.price = harga;
      p.costPrice = modal;
      p.stock = stok;
      p.unit = u.text.trim().isEmpty ? 'pcs' : u.text.trim();
      p.category = cat.text.trim().isEmpty ? 'Umum' : cat.text.trim();
      p.desc = d.text.trim();
      p.imageUrl = img.text.trim();
      p.sku = sku.text.trim();
      p.barcode = bc.text.trim();
      p.active = active;
    }
    store.save();
  }

  Future<void> quickStock(BuildContext context, Product p) async {
    final c = TextEditingController();
    final r = TextEditingController(text: 'Stok masuk');
    final tambah = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text('Stok ${p.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Stok saat ini: ${p.stock}'),
          const SizedBox(height: 8),
          TextField(
            controller: c,
            keyboardType: const TextInputType.numberWithOptions(signed: true),
            decoration: const InputDecoration(labelText: 'Jumlah (isi minus untuk kurangi, mis. -5)'),
          ),
          const SizedBox(height: 8),
          TextField(controller: r, decoration: const InputDecoration(labelText: 'Keterangan')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (tambah != true) return;
    final n = int.tryParse(c.text.trim()) ?? 0;
    if (n == 0) return;
    p.stock = (p.stock + n).clamp(0, 1 << 30);
    store.logStock(p.name, n, r.text.trim().isEmpty ? 'Penyesuaian manual' : r.text.trim());
    store.save();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => editProduct(context),
          icon: const Icon(Icons.add),
          label: const Text('Produk'),
        ),
        body: store.products.isEmpty
            ? const Center(child: Text('Belum ada produk'))
            : ListView.builder(
                padding: const EdgeInsets.only(bottom: 90),
                itemCount: store.products.length,
                itemBuilder: (_, i) {
                  final p = store.products[i];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: p.active ? Colors.green.shade50 : Colors.grey.shade300,
                      backgroundImage: p.imageUrl.isNotEmpty ? NetworkImage(p.imageUrl) : null,
                      child: p.imageUrl.isEmpty ? Icon(Icons.shopping_basket_outlined, color: p.active ? Colors.green : Colors.grey) : null,
                    ),
                    title: Text(p.name),
                    subtitle: Text('Jual ${rp(p.price)} • Beli ${rp(p.costPrice)} • ${p.category}${p.sku.isNotEmpty ? ' • SKU ${p.sku}' : ''}${p.active ? '' : ' • nonaktif'}'),
                    onTap: () => editProduct(context, p),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      InkWell(
                        onTap: () => quickStock(context, p),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: p.stock == 0 ? Colors.red.shade50 : Colors.green.shade50,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text('Stok ${p.stock}', style: TextStyle(color: p.stock == 0 ? Colors.red : Colors.green.shade800, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () {
                          store.products.remove(p);
                          store.save();
                        },
                      ),
                    ]),
                  );
                },
              ),
      ),
    );
  }
}

class OrdersAdminPage extends StatelessWidget {
  final bool onlineOnly;
  const OrdersAdminPage({super.key, this.onlineOnly = false});
  static const statuses = ['Baru', 'Diproses', 'Diantar', 'Selesai', 'Dibatalkan'];

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final list = onlineOnly ? store.orders.where((o) => o.channel == 'online').toList() : store.orders;
        return list.isEmpty
          ? Center(child: Text(onlineOnly ? 'Belum ada pesanan masuk' : 'Belum ada riwayat penjualan'))
          : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final o = list[i];
                return Card(
                  child: ExpansionTile(
                    leading: Icon(o.channel == 'kasir' ? Icons.point_of_sale : Icons.wifi, color: o.channel == 'kasir' ? Colors.orange : Colors.blue),
                    title: Text('${o.name} • ${rp(o.total)}'),
                    subtitle: Text('${o.channel == 'kasir' ? 'Kasir toko' : 'Online'} • ${o.date.day}/${o.date.month}/${o.date.year} ${o.date.hour}:${o.date.minute.toString().padLeft(2, '0')}'),
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          ...o.items.map((it) => Text('• ${it.name} x${it.qty} ${it.unit} = ${rp(it.subtotal)}')),
                          const SizedBox(height: 6),
                          Text('Alamat: ${o.address}'),
                          if (o.notes.isNotEmpty) Text('Catatan: ${o.notes}'),
                          const SizedBox(height: 8),
                          DropdownButton<String>(
                            value: o.status,
                            items: statuses.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                            onChanged: (v) {
                              if (v == null) return;
                              o.status = v;
                              store.saveOrders();
                            },
                          ),
                          const SizedBox(height: 4),
                          Text(o.lunas ? 'Lunas (${o.paymentMethod})' : 'Belum lunas • sisa ${rp(o.owing)}', style: TextStyle(color: o.lunas ? Colors.green.shade700 : Colors.red, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            icon: const Icon(Icons.receipt_outlined, size: 18),
                            label: const Text('Lihat Struk'),
                            onPressed: () => showReceipt(context, o),
                          ),
                          const SizedBox(height: 8),
                        ]),
                      ),
                    ],
                  ),
                );
              },
            );
      },
    );
  }
}

class ReportPage extends StatelessWidget {
  const ReportPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final now = DateTime.now();
        final valid = store.orders.where((o) => o.status != 'Dibatalkan');
        final today = valid.where((o) => o.date.year == now.year && o.date.month == now.month && o.date.day == now.day);
        final awalMinggu = now.subtract(Duration(days: now.weekday - 1));
        final week = valid.where((o) => o.date.isAfter(DateTime(awalMinggu.year, awalMinggu.month, awalMinggu.day)));
        final month = valid.where((o) => o.date.year == now.year && o.date.month == now.month);
        int sumOmzet(Iterable<CustomerOrder> l) => l.fold(0, (a, o) => a + o.total);
        int sumLaba(Iterable<CustomerOrder> l) => l.fold(0, (a, o) => a + o.profit);

        final Map<String, int> perProduk = {};
        for (final o in valid) {
          for (final it in o.items) {
            perProduk[it.name] = (perProduk[it.name] ?? 0) + it.qty;
          }
        }
        final top = perProduk.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(children: [
              Expanded(child: _StatCard(title: 'Omzet Hari Ini', value: rp(sumOmzet(today)), sub: '${today.length} transaksi')),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Laba Hari Ini', value: rp(sumLaba(today)), sub: 'perkiraan', accent: true)),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _StatCard(title: 'Omzet Minggu Ini', value: rp(sumOmzet(week)), sub: '${week.length} transaksi')),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Omzet Bulan Ini', value: rp(sumOmzet(month)), sub: '${month.length} transaksi')),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _StatCard(title: 'Laba Bulan Ini', value: rp(sumLaba(month)), sub: 'perkiraan', accent: true)),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Pengeluaran', value: rp(store.totalKeluar), sub: 'total tercatat')),
            ]),
            const SizedBox(height: 12),
            _StatCard(title: 'Total Transaksi Tercatat', value: '${store.orders.length}', sub: 'sejak aplikasi dipasang'),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.account_balance_wallet_outlined),
                label: const Text('Buka Rekap Kas'),
                onPressed: () => _openPage(context, 'Rekap Kas', const RekapKasPage()),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Laba dihitung dari harga jual dikurangi harga modal yang diisi di menu Produk. Isi harga modal agar laporan laba akurat.',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.calendar_month_outlined),
                  label: const Text('Omzet Per Bulan'),
                  onPressed: () => _openPage(context, 'Omzet Per Bulan', const OmzetBulananPage()),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.list_alt_outlined),
                  label: const Text('Produk Terjual'),
                  onPressed: () => _openPage(context, 'Produk Terjual', const ProdukTerjualPage()),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.ios_share),
                label: const Text('Ekspor Transaksi (CSV)'),
                onPressed: () async {
                  final b = StringBuffer('Tanggal,Nama,Channel,Status,Total,Laba\n');
                  for (final o in store.orders) {
                    b.writeln('${o.date.toIso8601String()},${csvEscape(o.name)},${o.channel},${o.status},${o.total},${o.profit}');
                  }
                  await exportCsv(context, 'transaksi_${store.shop}.csv', b.toString());
                },
              ),
            ),
            const SizedBox(height: 20),
            const Text('Produk Terlaris', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            if (top.isEmpty) const Text('Belum ada data penjualan'),
            ...top.take(10).map((e) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(e.key),
                  trailing: Text('${e.value} terjual'),
                )),
          ],
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title, value, sub;
  final bool accent;
  const _StatCard({required this.title, required this.value, required this.sub, this.accent = false});
  @override
  Widget build(BuildContext context) {
    return Card(
      color: accent ? Colors.green.shade50 : null,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: accent ? Colors.green.shade800 : null)),
          Text(sub, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        ]),
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = TextEditingController(text: store.shop);
    final w = TextEditingController(text: store.wa);
    final pn = TextEditingController(text: store.pin);
    final ad = TextEditingController(text: store.address);
    final an = TextEditingController(text: store.adminName);
    final qr = TextEditingController(text: store.qrisImageUrl);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Profil', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
        const SizedBox(height: 8),
        TextField(controller: an, decoration: const InputDecoration(labelText: 'Nama admin / kasir')),
        const SizedBox(height: 20),
        const Text('Profil Warung', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
        const SizedBox(height: 8),
        TextField(controller: s, decoration: const InputDecoration(labelText: 'Nama toko')),
        const SizedBox(height: 12),
        TextField(controller: w, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'No. WhatsApp (08xx atau 628xx)')),
        const SizedBox(height: 12),
        TextField(controller: ad, maxLines: 2, decoration: const InputDecoration(labelText: 'Alamat toko')),
        const SizedBox(height: 12),
        TextField(controller: pn, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'PIN admin')),
        const SizedBox(height: 20),
        const Text('Pembayaran QRIS', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
        const SizedBox(height: 8),
        TextField(controller: qr, decoration: const InputDecoration(labelText: 'URL gambar QRIS toko (opsional)', helperText: 'Upload gambar QRIS ke Google Drive/Imgur, tempel link gambarnya di sini')),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () {
            store.shop = s.text.trim().isEmpty ? store.shop : s.text.trim();
            store.wa = w.text.trim();
            store.address = ad.text.trim();
            store.pin = pn.text.trim().isEmpty ? store.pin : pn.text.trim();
            store.adminName = an.text.trim();
            store.qrisImageUrl = qr.text.trim();
            store.save();
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pengaturan disimpan')));
          },
          child: const Text('Simpan Pengaturan'),
        ),
      ],
    );
  }
}
