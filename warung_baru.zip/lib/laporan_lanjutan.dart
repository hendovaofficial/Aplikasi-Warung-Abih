import 'package:flutter/material.dart';
import 'data.dart';

class OmzetBulananPage extends StatelessWidget {
  const OmzetBulananPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final valid = store.orders.where((o) => o.status != 'Dibatalkan');
        final Map<String, List<CustomerOrder>> byMonth = {};
        for (final o in valid) {
          final key = '${o.date.year}-${o.date.month.toString().padLeft(2, '0')}';
          byMonth.putIfAbsent(key, () => []).add(o);
        }
        final keys = byMonth.keys.toList()..sort((a, b) => b.compareTo(a));
        const bulanNama = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
        if (keys.isEmpty) return const Center(child: Text('Belum ada data'));
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: keys.length,
          itemBuilder: (_, i) {
            final k = keys[i];
            final list = byMonth[k]!;
            final omzet = list.fold(0, (a, o) => a + o.total);
            final laba = list.fold(0, (a, o) => a + o.profit);
            final parts = k.split('-');
            final label = '${bulanNama[int.parse(parts[1])]} ${parts[0]}';
            return Card(
              child: ListTile(
                title: Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${list.length} transaksi • Laba ${rp(laba)}'),
                trailing: Text(rp(omzet), style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            );
          },
        );
      },
    );
  }
}

class ProdukTerjualPage extends StatelessWidget {
  const ProdukTerjualPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final valid = store.orders.where((o) => o.status != 'Dibatalkan');
        final Map<String, int> qty = {};
        final Map<String, int> omzet = {};
        final Map<String, int> laba = {};
        for (final o in valid) {
          for (final it in o.items) {
            qty[it.name] = (qty[it.name] ?? 0) + it.qty;
            omzet[it.name] = (omzet[it.name] ?? 0) + it.subtotal;
            laba[it.name] = (laba[it.name] ?? 0) + it.profit;
          }
        }
        final names = qty.keys.toList()..sort((a, b) => (qty[b] ?? 0).compareTo(qty[a] ?? 0));
        if (names.isEmpty) return const Center(child: Text('Belum ada data penjualan'));
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: names.length,
          itemBuilder: (_, i) {
            final n = names[i];
            return Card(
              child: ListTile(
                title: Text(n),
                subtitle: Text('${qty[n]} terjual • Laba ${rp(laba[n] ?? 0)}'),
                trailing: Text(rp(omzet[n] ?? 0), style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            );
          },
        );
      },
    );
  }
}
