import 'package:flutter/material.dart';
import 'data.dart';

class DebtPage extends StatelessWidget {
  const DebtPage({super.key});

  Future<void> bayar(BuildContext context, CustomerOrder o) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text('Pelunasan • ${o.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Total: ${rp(o.total)}'),
          Text('Sudah dibayar: ${rp(o.paid)}'),
          Text('Sisa hutang: ${rp(o.owing)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
          const SizedBox(height: 12),
          TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Jumlah bayar sekarang')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true) return;
    final bayar = int.tryParse(c.text.trim()) ?? 0;
    if (bayar <= 0) return;
    o.paid = (o.paid + bayar).clamp(0, o.total);
    store.saveOrders();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final hutang = store.orders.where((o) => !o.lunas).toList();
        final totalHutang = hutang.fold(0, (a, o) => a + o.owing);
        return Column(children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(12)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Total Piutang Belum Lunas', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 4),
              Text(rp(totalHutang), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.red)),
            ]),
          ),
          Expanded(
            child: hutang.isEmpty
                ? const Center(child: Text('Tidak ada hutang, semua transaksi lunas 🎉'))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: hutang.length,
                    itemBuilder: (_, i) {
                      final o = hutang[i];
                      return Card(
                        child: ListTile(
                          title: Text(o.name),
                          subtitle: Text('Total ${rp(o.total)} • Sisa ${rp(o.owing)} • ${o.date.day}/${o.date.month}/${o.date.year}'),
                          trailing: FilledButton(onPressed: () => bayar(context, o), child: const Text('Bayar')),
                        ),
                      );
                    },
                  ),
          ),
        ]);
      },
    );
  }
}
