import 'package:flutter/material.dart';
import 'data.dart';

class EmployeePage extends StatelessWidget {
  const EmployeePage({super.key});

  Future<void> editEmployee(BuildContext context, [Employee? e]) async {
    final n = TextEditingController(text: e?.name ?? '');
    final ph = TextEditingController(text: e?.phone ?? '');
    final role = TextEditingController(text: e?.role ?? 'Karyawan');
    bool active = e?.active ?? true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setS) => AlertDialog(
          title: Text(e == null ? 'Tambah Karyawan' : 'Edit Karyawan'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: n, decoration: const InputDecoration(labelText: 'Nama')),
            TextField(controller: ph, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'No. HP (opsional)')),
            TextField(controller: role, decoration: const InputDecoration(labelText: 'Jabatan (mis. Kasir, Pengantar)')),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Masih aktif bekerja'),
              value: active,
              onChanged: (v) => setS(() => active = v),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
          ],
        ),
      ),
    );
    if (ok != true || n.text.trim().isEmpty) return;
    if (e == null) {
      store.employees.add(Employee(id: DateTime.now().millisecondsSinceEpoch.toString(), name: n.text.trim(), phone: ph.text.trim(), role: role.text.trim(), active: active));
    } else {
      e.name = n.text.trim();
      e.phone = ph.text.trim();
      e.role = role.text.trim();
      e.active = active;
    }
    store.saveEmployees();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => editEmployee(context),
          icon: const Icon(Icons.person_add_alt_1),
          label: const Text('Karyawan'),
        ),
        body: store.employees.isEmpty
            ? const Center(child: Text('Belum ada data karyawan'))
            : ListView.builder(
                padding: const EdgeInsets.only(bottom: 90),
                itemCount: store.employees.length,
                itemBuilder: (_, i) {
                  final e = store.employees[i];
                  return ListTile(
                    leading: CircleAvatar(backgroundColor: e.active ? Colors.green.shade50 : Colors.grey.shade300, child: Icon(Icons.badge_outlined, color: e.active ? Colors.green : Colors.grey)),
                    title: Text(e.name),
                    subtitle: Text('${e.role}${e.phone.isNotEmpty ? ' • ${e.phone}' : ''}${e.active ? '' : ' • nonaktif'}'),
                    onTap: () => editEmployee(context, e),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        store.employees.remove(e);
                        store.saveEmployees();
                      },
                    ),
                  );
                },
              ),
      ),
    );
  }
}
