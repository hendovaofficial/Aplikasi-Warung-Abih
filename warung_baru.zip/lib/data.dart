import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

String rp(num n) =>
    'Rp${n.toInt().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => '.')}';

class Product {
  String id, name, unit, category, desc, imageUrl, sku, barcode;
  int price, stock, costPrice;
  bool active, trackStock;
  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.unit,
    this.category = 'Umum',
    this.stock = 0,
    this.desc = '',
    this.imageUrl = '',
    this.active = true,
    this.costPrice = 0,
    this.sku = '',
    this.barcode = '',
    this.trackStock = true,
  });
  Map<String, dynamic> toJson() => {
        'id': id,
        'n': name,
        'p': price,
        'u': unit,
        'c': category,
        's': stock,
        'd': desc,
        'img': imageUrl,
        'a': active,
        'cost': costPrice,
        'sku': sku,
        'bc': barcode,
        'ts': trackStock,
      };
  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'],
        name: j['n'],
        price: j['p'],
        unit: j['u'],
        category: j['c'] ?? 'Umum',
        stock: j['s'] ?? 0,
        desc: j['d'] ?? '',
        imageUrl: j['img'] ?? '',
        active: j['a'] ?? true,
        costPrice: j['cost'] ?? 0,
        sku: j['sku'] ?? '',
        barcode: j['bc'] ?? '',
        trackStock: j['ts'] ?? true,
      );
}

class OrderItem {
  String name, unit;
  int price, qty, costPrice;
  OrderItem(this.name, this.price, this.qty, this.unit, [this.costPrice = 0]);
  int get subtotal => price * qty;
  int get profit => (price - costPrice) * qty;
  Map<String, dynamic> toJson() => {'n': name, 'p': price, 'q': qty, 'u': unit, 'cost': costPrice};
  factory OrderItem.fromJson(Map<String, dynamic> j) =>
      OrderItem(j['n'], j['p'], j['q'], j['u'] ?? '', j['cost'] ?? 0);
}

class Customer {
  String id, name, phone, address;
  Customer({required this.id, required this.name, this.phone = '', this.address = ''});
  Map<String, dynamic> toJson() => {'id': id, 'n': name, 'ph': phone, 'addr': address};
  factory Customer.fromJson(Map<String, dynamic> j) =>
      Customer(id: j['id'], name: j['n'], phone: j['ph'] ?? '', address: j['addr'] ?? '');
}

class StockLog {
  String id, productName, reason;
  int change; // positive = masuk, negative = keluar
  DateTime date;
  StockLog({required this.id, required this.productName, required this.change, required this.reason, required this.date});
  Map<String, dynamic> toJson() => {'id': id, 'n': productName, 'ch': change, 'r': reason, 'd': date.toIso8601String()};
  factory StockLog.fromJson(Map<String, dynamic> j) => StockLog(
        id: j['id'],
        productName: j['n'],
        change: j['ch'],
        reason: j['r'] ?? '',
        date: DateTime.parse(j['d']),
      );
}

class CustomerOrder {
  String id, name, address, notes, status, channel, paymentMethod; // channel: 'online' or 'kasir'
  DateTime date;
  List<OrderItem> items;
  int paid; // jumlah yang sudah dibayar; jika < total maka sisanya hutang
  CustomerOrder({
    required this.id,
    required this.name,
    required this.address,
    required this.notes,
    required this.items,
    required this.date,
    this.status = 'Baru',
    this.channel = 'online',
    this.paymentMethod = 'Tunai',
    int? paid,
  }) : paid = paid ?? items.fold(0, (a, e) => a + e.subtotal);
  int get total => items.fold(0, (a, e) => a + e.subtotal);
  int get profit => items.fold(0, (a, e) => a + e.profit);
  int get owing => (total - paid).clamp(0, 1 << 62);
  bool get lunas => owing <= 0;
  Map<String, dynamic> toJson() => {
        'id': id,
        'n': name,
        'addr': address,
        'notes': notes,
        'items': items.map((e) => e.toJson()).toList(),
        'date': date.toIso8601String(),
        'status': status,
        'ch': channel,
        'pm': paymentMethod,
        'paid': paid,
      };
  factory CustomerOrder.fromJson(Map<String, dynamic> j) => CustomerOrder(
        id: j['id'],
        name: j['n'],
        address: j['addr'],
        notes: j['notes'] ?? '',
        items: (j['items'] as List)
            .map((e) => OrderItem.fromJson(e as Map<String, dynamic>))
            .toList(),
        date: DateTime.parse(j['date']),
        status: j['status'] ?? 'Baru',
        channel: j['ch'] ?? 'online',
        paymentMethod: j['pm'] ?? 'Tunai',
        paid: j['paid'],
      );
}

class Store extends ChangeNotifier {
  late SharedPreferences sp;
  List<Product> products = [];
  List<CustomerOrder> orders = [];
  List<Customer> customers = [];
  List<StockLog> stockLogs = [];
  List<String> customCategories = [];
  String shop = 'Warung Abih', wa = '', pin = '1234', address = '', adminName = '', qrisImageUrl = '';
  final Map<String, int> cart = {}; // productId -> qty

  Product? byId(String id) {
    for (final p in products) {
      if (p.id == id) return p;
    }
    return null;
  }

  Future<void> load() async {
    sp = await SharedPreferences.getInstance();
    shop = sp.getString('shop') ?? shop;
    wa = sp.getString('wa') ?? '';
    pin = sp.getString('pin') ?? pin;
    address = sp.getString('address') ?? '';
    adminName = sp.getString('adminName') ?? '';
    qrisImageUrl = sp.getString('qrisImageUrl') ?? '';
    customCategories = sp.getStringList('customCategories') ?? ['Sembako', 'Segar', 'Instan', 'Minuman', 'Cemilan'];
    final ps = sp.getString('products');
    if (ps == null) {
      products = [
        Product(id: 'p1', name: 'Beras', price: 13000, costPrice: 11500, unit: 'kg', category: 'Sembako', stock: 50),
        Product(id: 'p2', name: 'Minyak Goreng', price: 18000, costPrice: 16000, unit: 'liter', category: 'Sembako', stock: 30),
        Product(id: 'p3', name: 'Gula Pasir', price: 17000, costPrice: 15000, unit: 'kg', category: 'Sembako', stock: 40),
        Product(id: 'p4', name: 'Telur Ayam', price: 28000, costPrice: 25000, unit: 'kg', category: 'Segar', stock: 20),
        Product(id: 'p5', name: 'Mie Instan', price: 3500, costPrice: 2800, unit: 'bungkus', category: 'Instan', stock: 100),
        Product(id: 'p6', name: 'Kopi Sachet', price: 1500, costPrice: 1100, unit: 'pcs', category: 'Minuman', stock: 80),
      ];
      save();
    } else {
      products = (jsonDecode(ps) as List)
          .map((e) => Product.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final os = sp.getString('orders');
    if (os != null) {
      orders = (jsonDecode(os) as List)
          .map((e) => CustomerOrder.fromJson(e as Map<String, dynamic>))
          .toList();
      orders.sort((a, b) => b.date.compareTo(a.date));
    }
    final cs = sp.getString('customers');
    if (cs != null) {
      customers = (jsonDecode(cs) as List)
          .map((e) => Customer.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final sl = sp.getString('stockLogs');
    if (sl != null) {
      stockLogs = (jsonDecode(sl) as List)
          .map((e) => StockLog.fromJson(e as Map<String, dynamic>))
          .toList();
      stockLogs.sort((a, b) => b.date.compareTo(a.date));
    }
  }

  void save() {
    sp.setString('products', jsonEncode(products.map((e) => e.toJson()).toList()));
    sp.setString('shop', shop);
    sp.setString('wa', wa);
    sp.setString('pin', pin);
    sp.setString('address', address);
    sp.setString('adminName', adminName);
    sp.setString('qrisImageUrl', qrisImageUrl);
    notifyListeners();
  }

  void saveCategories() {
    sp.setStringList('customCategories', customCategories);
    notifyListeners();
  }

  void saveOrders() {
    sp.setString('orders', jsonEncode(orders.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  void saveCustomers() {
    sp.setString('customers', jsonEncode(customers.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  void logStock(String productName, int change, String reason) {
    stockLogs.insert(
      0,
      StockLog(id: '${DateTime.now().microsecondsSinceEpoch}', productName: productName, change: change, reason: reason, date: DateTime.now()),
    );
    if (stockLogs.length > 500) stockLogs.removeRange(500, stockLogs.length);
    sp.setString('stockLogs', jsonEncode(stockLogs.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  void addToCart(Product p) {
    cart[p.id] = (cart[p.id] ?? 0) + 1;
    notifyListeners();
  }

  void subFromCart(Product p) {
    final q = (cart[p.id] ?? 0) - 1;
    if (q <= 0) {
      cart.remove(p.id);
    } else {
      cart[p.id] = q;
    }
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    notifyListeners();
  }

  int get cartCount => cart.values.fold(0, (a, b) => a + b);
  int get cartTotal {
    int t = 0;
    cart.forEach((id, q) {
      final p = byId(id);
      if (p != null) t += p.price * q;
    });
    return t;
  }

  List<String> get categories {
    final s = <String>{'Semua'};
    s.addAll(customCategories);
    for (final p in products) {
      s.add(p.category);
    }
    return s.toList();
  }
}

final store = Store();
