import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

String rp(num n) =>
    'Rp${n.toInt().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => '.')}';

class Product {
  String id, name, unit, category, desc, imageUrl;
  int price, stock, costPrice;
  bool active;
  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.unit,
    this.category = 'Umum',
    this.stock = 0,
    this.desc = '',
    this.imageUrl = '',
    this.active = true,
    this.costPrice = 0,
  });
  Map<String, dynamic> toJson() => {
        'id': id,
        'n': name,
        'p': price,
        'u': unit,
        'c': category,
        's': stock,
        'd': desc,
        'img': imageUrl,
        'a': active,
        'cost': costPrice,
      };
  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'],
        name: j['n'],
        price: j['p'],
        unit: j['u'],
        category: j['c'] ?? 'Umum',
        stock: j['s'] ?? 0,
        desc: j['d'] ?? '',
        imageUrl: j['img'] ?? '',
        active: j['a'] ?? true,
        costPrice: j['cost'] ?? 0,
      );
}

class OrderItem {
  String name, unit;
  int price, qty, costPrice;
  OrderItem(this.name, this.price, this.qty, this.unit, [this.costPrice = 0]);
  int get subtotal => price * qty;
  int get profit => (price - costPrice) * qty;
  Map<String, dynamic> toJson() => {'n': name, 'p': price, 'q': qty, 'u': unit, 'cost': costPrice};
  factory OrderItem.fromJson(Map<String, dynamic> j) =>
      OrderItem(j['n'], j['p'], j['q'], j['u'] ?? '', j['cost'] ?? 0);
}

class CustomerOrder {
  String id, name, address, notes, status, channel; // channel: 'online' or 'kasir'
  DateTime date;
  List<OrderItem> items;
  CustomerOrder({
    required this.id,
    required this.name,
    required this.address,
    required this.notes,
    required this.items,
    required this.date,
    this.status = 'Baru',
    this.channel = 'online',
  });
  int get total => items.fold(0, (a, e) => a + e.subtotal);
  int get profit => items.fold(0, (a, e) => a + e.profit);
  Map<String, dynamic> toJson() => {
        'id': id,
        'n': name,
        'addr': address,
        'notes': notes,
        'items': items.map((e) => e.toJson()).toList(),
        'date': date.toIso8601String(),
        'status': status,
        'ch': channel,
      };
  factory CustomerOrder.fromJson(Map<String, dynamic> j) => CustomerOrder(
        id: j['id'],
        name: j['n'],
        address: j['addr'],
        notes: j['notes'] ?? '',
        items: (j['items'] as List)
            .map((e) => OrderItem.fromJson(e as Map<String, dynamic>))
            .toList(),
        date: DateTime.parse(j['date']),
        status: j['status'] ?? 'Baru',
        channel: j['ch'] ?? 'online',
      );
}

class Store extends ChangeNotifier {
  late SharedPreferences sp;
  List<Product> products = [];
  List<CustomerOrder> orders = [];
  String shop = 'Warung Abih', wa = '', pin = '1234', address = '';
  final Map<String, int> cart = {}; // productId -> qty

  Product? byId(String id) {
    for (final p in products) {
      if (p.id == id) return p;
    }
    return null;
  }

  Future<void> load() async {
    sp = await SharedPreferences.getInstance();
    shop = sp.getString('shop') ?? shop;
    wa = sp.getString('wa') ?? '';
    pin = sp.getString('pin') ?? pin;
    address = sp.getString('address') ?? '';
    final ps = sp.getString('products');
    if (ps == null) {
      products = [
        Product(id: 'p1', name: 'Beras', price: 13000, costPrice: 11500, unit: 'kg', category: 'Sembako', stock: 50),
        Product(id: 'p2', name: 'Minyak Goreng', price: 18000, costPrice: 16000, unit: 'liter', category: 'Sembako', stock: 30),
        Product(id: 'p3', name: 'Gula Pasir', price: 17000, costPrice: 15000, unit: 'kg', category: 'Sembako', stock: 40),
        Product(id: 'p4', name: 'Telur Ayam', price: 28000, costPrice: 25000, unit: 'kg', category: 'Segar', stock: 20),
        Product(id: 'p5', name: 'Mie Instan', price: 3500, costPrice: 2800, unit: 'bungkus', category: 'Instan', stock: 100),
        Product(id: 'p6', name: 'Kopi Sachet', price: 1500, costPrice: 1100, unit: 'pcs', category: 'Minuman', stock: 80),
      ];
      save();
    } else {
      products = (jsonDecode(ps) as List)
          .map((e) => Product.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final os = sp.getString('orders');
    if (os != null) {
      orders = (jsonDecode(os) as List)
          .map((e) => CustomerOrder.fromJson(e as Map<String, dynamic>))
          .toList();
      orders.sort((a, b) => b.date.compareTo(a.date));
    }
  }

  void save() {
    sp.setString('products', jsonEncode(products.map((e) => e.toJson()).toList()));
    sp.setString('shop', shop);
    sp.setString('wa', wa);
    sp.setString('pin', pin);
    sp.setString('address', address);
    notifyListeners();
  }

  void saveOrders() {
    sp.setString('orders', jsonEncode(orders.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  void addToCart(Product p) {
    cart[p.id] = (cart[p.id] ?? 0) + 1;
    notifyListeners();
  }

  void subFromCart(Product p) {
    final q = (cart[p.id] ?? 0) - 1;
    if (q <= 0) {
      cart.remove(p.id);
    } else {
      cart[p.id] = q;
    }
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    notifyListeners();
  }

  int get cartCount => cart.values.fold(0, (a, b) => a + b);
  int get cartTotal {
    int t = 0;
    cart.forEach((id, q) {
      final p = byId(id);
      if (p != null) t += p.price * q;
    });
    return t;
  }

  List<String> get categories {
    final s = <String>{'Semua'};
    for (final p in products) {
      s.add(p.category);
    }
    return s.toList();
  }
}

final store = Store();
