import 'package:flutter/material.dart';
import 'data.dart';

class CategoryPage extends StatelessWidget {
  const CategoryPage({super.key});

  Future<void> addCategory(BuildContext context) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Tambah Kategori'),
        content: TextField(controller: c, decoration: const InputDecoration(labelText: 'Nama kategori')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true || c.text.trim().isEmpty) return;
    if (!store.customCategories.contains(c.text.trim())) {
      store.customCategories.add(c.text.trim());
      store.saveCategories();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => addCategory(context),
          icon: const Icon(Icons.add),
          label: const Text('Kategori'),
        ),
        body: store.customCategories.isEmpty
            ? const Center(child: Text('Belum ada kategori'))
            : ListView.builder(
                padding: const EdgeInsets.only(bottom: 90),
                itemCount: store.customCategories.length,
                itemBuilder: (_, i) {
                  final c = store.customCategories[i];
                  final jumlah = store.products.where((p) => p.category == c).length;
                  return ListTile(
                    leading: const Icon(Icons.sell_outlined),
                    title: Text(c),
                    subtitle: Text('$jumlah produk'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        store.customCategories.remove(c);
                        store.saveCategories();
                      },
                    ),
                  );
                },
              ),
      ),
    );
  }
}
